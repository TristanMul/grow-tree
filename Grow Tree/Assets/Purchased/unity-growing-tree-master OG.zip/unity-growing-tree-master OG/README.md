# Growing tree

![A procedural growing tree](https://ciphered.xyz/wp-content/uploads/2019/09/ig-353.gif)

This code is a follow-up to the article I wrote on my blog: [https://ciphered.xyz/2019/09/11/generating-a-3d-growing-tree-using-a-space-colonization-algorithm/](https://ciphered.xyz/2019/09/11/generating-a-3d-growing-tree-using-a-space-colonization-algorithm/).

If you want details on the algorithm, please check the article.

![Steps of generation](https://ciphered.xyz/wp-content/uploads/2019/09/Thumbnail.gif)